# 📊 Portfolio AI Manager — 설치 & 실행 가이드

## 빠른 시작

```bash
# 1. 패키지 설치
pip install -r requirements.txt

# 2. API 키 설정
cp .env.example .env
# .env 파일 열어서 키 입력

# 3. 실행
streamlit run app.py
```

---

## API 키 발급

| API | 발급 URL | 비용 |
|-----|----------|------|
| **Gemini** | https://aistudio.google.com/app/apikey | 무료 티어 있음 |
| **Notion** | https://www.notion.so/my-integrations | 무료 |

### Notion 데이터베이스 설정

1. Notion에 새 데이터베이스(전체 페이지) 생성
2. 아래 속성 추가:

| 속성명 | 타입 |
|--------|------|
| 제목 | 제목 (기본값) |
| 날짜 | 날짜 |
| 자산 | 텍스트 |
| 카테고리 | 텍스트 |
| 출처 | 텍스트 |
| 요약 | 텍스트 |
| 링크 | URL |

3. Integration을 데이터베이스에 연결 (우측 상단 … → 연결)
4. DB ID = Notion URL에서 추출 (`notion.so/xxxxxxxx?v=...` → `xxxxxxxx` 부분, 하이픈 포함)

---

## 티커 형식

| 자산 | 형식 | 예시 |
|------|------|------|
| 코스피 | 숫자.KS | `005930.KS` (삼성전자), `000660.KS` (SK하이닉스) |
| 코스닥 | 숫자.KQ | `035720.KQ` (카카오), `247540.KQ` (에코프로비엠) |
| 미국 주식 | 알파벳 | `AAPL`, `TSLA`, `NVDA`, `MSFT` |
| 미국 ETF | 알파벳 | `QQQ`, `SPY`, `ARKK`, `TLT`, `GLD` |
| 한국 ETF | 숫자.KS | `069500.KS` (KODEX200), `148070.KS` (KODEX 미국나스닥100) |
| 암호화폐 | 심볼 or 심볼-USD | `BTC`, `ETH`, `SOL`, `BTC-USD`, `ETH-USD` |

---

## 기능 설명

| 페이지 | 기능 |
|--------|------|
| 🏠 대시보드 | 12개 시장 지표 실시간 + 포트폴리오 총괄 차트 |
| 💼 포트폴리오 관리 | 자산 추가/수정/삭제 + 캔들차트 + MA20/60 |
| ₿ 암호화폐 | 주요 코인 실시간 + 보유 코인 + 코인 전용 뉴스 |
| 📰 뉴스 & 리서치 | 종목별/시장전반 구글 뉴스 실시간 (한/영) |
| 📎 스크랩북 | 필터/정렬 + Notion 자동 동기화 |
| 🤖 AI 분석 | Gemini 기반 맞춤 투자 전략 (헷지, 리스크, 로드맵 포함) |

---

## 데이터 저장 위치

포트폴리오 데이터는 `utils/portfolio_db.json`에 로컬 저장됩니다.  
정기 백업 권장: `cp utils/portfolio_db.json backup_$(date +%Y%m%d).json`
