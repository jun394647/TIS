"""
utils/ai.py — Gemini 기반 포트폴리오 분석
"""
import os
from datetime import datetime


def get_gemini_analysis(portfolio_df, scraps: list, market_indices: list, prompt_extra: str = "") -> str:
    api_key = os.getenv("GEMINI_API_KEY","").strip()
    if not api_key or api_key.startswith("your_"):
        return "⚠️ Gemini API 키가 설정되지 않았습니다. 사이드바에서 입력해주세요."
    try:
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel("gemini-2.5-flash")
    except Exception as e:
        return f"⚠️ Gemini 초기화 오류: {e}"

    # 포트폴리오 요약
    if portfolio_df is not None and not portfolio_df.empty:
        total_value_krw = portfolio_df["현재가치(KRW)"].sum()
        total_pl_krw = portfolio_df["손익(KRW)"].sum()
        total_pl_pct = (total_pl_krw / (total_value_krw - total_pl_krw) * 100) if (total_value_krw - total_pl_krw) else 0

        # 자산 유형별 비중
        type_weights = portfolio_df.groupby("유형")["현재가치(KRW)"].sum()
        type_pct = (type_weights / type_weights.sum() * 100).round(1)
        type_summary = ", ".join([f"{t}: {p}%" for t, p in type_pct.items()])

        portfolio_section = f"""
## 📊 현재 포트폴리오
- 총 평가가치: {total_value_krw:,.0f} KRW
- 총 손익: {total_pl_krw:+,.0f} KRW ({total_pl_pct:+.1f}%)
- 자산 유형 비중: {type_summary}

### 종목별 현황
{portfolio_df[['티커','종목명','유형','현재가치(KRW)','손익률(%)','섹터','등락률(%)']].to_string(index=False)}
"""
    else:
        portfolio_section = "## 📊 포트폴리오\n(등록된 자산 없음)"

    # 시장 지표
    indices_lines = [f"- {m['name']}: {m['value']:,} ({m['change_pct']:+.2f}%)" for m in market_indices]
    indices_section = "## 🌍 주요 시장 지표\n" + "\n".join(indices_lines) if indices_lines else ""

    # 스크랩 뉴스 (최근 15개)
    recent = sorted(scraps, key=lambda x: x.get("scraped_at",""), reverse=True)[:15]
    if recent:
        scrap_lines = [f"[{s['ticker']}][{s['category']}] {s['title']} ({s.get('scraped_at','')[:10]})" for s in recent]
        scraps_section = "## 📎 최근 스크랩 정보\n" + "\n".join(scrap_lines)
    else:
        scraps_section = "## 📎 스크랩\n(없음)"

    system_prompt = """당신은 20년 경력의 멀티에셋 포트폴리오 매니저입니다.

투자 철학:
• 자본 보전 우선 + 중장기 알파 추구
• 변동성 대비 수익률(샤프비율) 최적화
• 헷지 포지션(인버스 ETF, 금, 채권, 달러 현금)을 적극 활용
• 섹터/국가/자산군 분산으로 상관관계 리스크 최소화

응답 형식 (마크다운):
1. **종합 진단** — 포트폴리오 강점·취약점 (3줄)
2. **시황 해석** — 현재 지표가 말하는 것 (금리, 달러, VIX 등)
3. **즉시 액션 플랜** — 매수/매도/비중조정 구체 제안 (종목명 포함)
4. **헷지 전략** — 리스크 유형별 헷지 방법 제안
5. **단기(1개월) / 중기(3-6개월) 로드맵**
6. **핵심 리스크 요인** — 주의해야 할 3가지

한국어로, 실제 투자자에게 브리핑하듯 명확하고 구체적으로 작성하세요."""

    user_msg = f"""{portfolio_section}

{indices_section}

{scraps_section}

현재 날짜: {datetime.now().strftime('%Y년 %m월 %d일 %H:%M')}
{f"추가 요청: {prompt_extra}" if prompt_extra else ""}

위 데이터를 종합해 포트폴리오 운용 전략을 브리핑해주세요."""

    try:
        resp = model.generate_content(
            system_prompt + "\n\n" + user_msg,
            generation_config={"temperature": 0.65, "max_output_tokens": 2500}
        )
        return resp.text
    except Exception as e:
        return f"⚠️ Gemini 분석 오류: {e}"
