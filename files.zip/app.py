import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import os, sys
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()
sys.path.insert(0, os.path.dirname(__file__))

from utils.data import (
    get_stock_info, get_price_history, get_portfolio_summary,
    get_market_indices, get_news_for_asset, get_general_market_news, get_crypto_news,
    load_portfolio, add_asset, update_asset, remove_asset,
    add_scrap, get_scraps, delete_scrap, save_to_notion,
    ASSET_TYPES, ASSET_TYPE_ICONS, detect_asset_type, get_usd_krw_rate, normalize_crypto_ticker
)

# ── 버전 호환: 신규 함수 안전 import ──────────────────────────────────────────
try:
    from utils.data import get_research_news
except ImportError:
    def get_research_news(query: str, max_items: int = 8) -> list:
        """get_research_news 미지원 버전 폴백 — get_general_market_news 대체"""
        return get_general_market_news(max_items)

try:
    from utils.data import get_jpy_krw_rate
except ImportError:
    def get_jpy_krw_rate() -> float:
        """get_jpy_krw_rate 미지원 버전 폴백"""
        try:
            import yfinance as yf
            usd_jpy = yf.Ticker("JPY=X").history(period="2d")
            usd_krw = yf.Ticker("KRW=X").history(period="2d")
            if not usd_jpy.empty and not usd_krw.empty:
                return round((float(usd_krw["Close"].iloc[-1]) / float(usd_jpy["Close"].iloc[-1])) * 100, 2)
        except:
            pass
        return 900.0

from utils.ai import get_gemini_analysis

# ── 페이지 설정 ────────────────────────────────────────────────────────────────
st.set_page_config(page_title="Portfolio AI", page_icon="📈", layout="wide", initial_sidebar_state="expanded")

# ── CSS ────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300;400;500;700;900&family=Space+Mono:wght@400;700&display=swap');

:root {
    --bg: #06090f;
    --bg1: #0c1220;
    --bg2: #111c2e;
    --bg3: #172238;
    --accent: #00e5b4;
    --accent2: #4d9fff;
    --accent3: #f59e0b;
    --red: #ff4466;
    --text: #dde5f0;
    --muted: #6b7f99;
    --border: #1a2d47;
}

*, html, body { box-sizing: border-box; }
html, body, [class*="css"] { font-family: 'Noto Sans KR', sans-serif !important; background: var(--bg) !important; color: var(--text); }
.stApp { background: var(--bg) !important; }
[data-testid="stSidebar"] { background: var(--bg1) !important; border-right: 1px solid var(--border); }
[data-testid="stSidebar"] * { color: var(--text) !important; }

/* header bar */
.header-bar {
    background: linear-gradient(135deg, var(--bg1) 0%, var(--bg2) 100%);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 20px 28px;
    margin-bottom: 20px;
    display: flex; align-items: center; gap: 16px;
}
.logo-main { font-size: 28px; font-weight: 900; letter-spacing: -1px;
    background: linear-gradient(90deg, var(--accent), var(--accent2));
    -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.logo-sub { font-size: 12px; color: var(--muted); margin-top: 2px; }

/* stat card */
.stat-card {
    background: var(--bg2); border: 1px solid var(--border);
    border-radius: 14px; padding: 18px 22px;
    transition: border-color 0.2s, transform 0.15s;
}
.stat-card:hover { border-color: var(--accent2); transform: translateY(-2px); }
.stat-label { font-size: 10px; color: var(--muted); text-transform: uppercase; letter-spacing: 1.2px; margin-bottom: 6px; }
.stat-value { font-family: 'Space Mono', monospace; font-size: 20px; font-weight: 700; color: var(--text); }
.stat-sub { font-family: 'Space Mono', monospace; font-size: 12px; margin-top: 4px; }
.up { color: var(--accent) !important; }
.dn { color: var(--red) !important; }
.neu { color: var(--muted) !important; }

/* index pill */
.idx-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px,1fr)); gap: 8px; }
.idx-pill {
    background: var(--bg3); border: 1px solid var(--border);
    border-radius: 10px; padding: 10px 14px; text-align: center;
    transition: border-color 0.2s;
}
.idx-pill:hover { border-color: var(--accent2); }
.idx-name { font-size: 9px; color: var(--muted); letter-spacing: 0.8px; text-transform: uppercase; margin-bottom: 4px; }
.idx-val { font-family: 'Space Mono', monospace; font-size: 14px; font-weight: 700; }
.idx-chg { font-family: 'Space Mono', monospace; font-size: 10px; margin-top: 2px; }

/* news card */
.nc {
    background: var(--bg2); border: 1px solid var(--border);
    border-radius: 10px; padding: 12px 16px; margin-bottom: 8px;
    transition: border-color 0.15s;
}
.nc:hover { border-color: var(--accent2); }
.nc-title { font-size: 13px; font-weight: 500; margin-bottom: 4px; }
.nc-title a { color: var(--text); text-decoration: none; }
.nc-title a:hover { color: var(--accent2); }
.nc-meta { font-size: 10px; color: var(--muted); }

/* section title */
.sec { font-size: 16px; font-weight: 700; color: var(--text);
    border-left: 3px solid var(--accent); padding-left: 10px; margin: 20px 0 12px 0; }

/* tag */
.tag { display:inline-block; background:var(--bg3); border:1px solid var(--border);
    border-radius:20px; padding:2px 9px; font-size:10px; color:var(--accent2); margin-right:4px; }

/* type badge */
.badge { display:inline-block; border-radius:6px; padding:2px 8px; font-size:10px; font-weight:600; }
.b-kr { background:#1a2e20; color:#4ade80; }
.b-us { background:#1a2535; color:#60a5fa; }
.b-etf { background:#2a2010; color:#fbbf24; }
.b-crypto { background:#2a1520; color:#f472b6; }
.b-other { background:#1e1e2a; color:#a78bfa; }

/* ai box */
.ai-box {
    background: linear-gradient(135deg, #0c1e38 0%, #071428 100%);
    border: 1px solid #1e3d63; border-left: 3px solid var(--accent2);
    border-radius: 14px; padding: 24px 28px;
    font-size: 14px; line-height: 1.85; color: var(--text);
}

/* buttons */
.stButton > button {
    background: var(--bg3) !important; color: var(--text) !important;
    border: 1px solid var(--border) !important; border-radius: 8px !important;
    font-family: 'Noto Sans KR', sans-serif !important;
    transition: all 0.15s !important;
}
.stButton > button:hover { border-color: var(--accent) !important; color: var(--accent) !important; }

/* inputs */
.stTextInput input, .stNumberInput input { background: var(--bg2) !important; color: var(--text) !important; border-color: var(--border) !important; }
.stSelectbox > div { background: var(--bg2) !important; }

hr { border-color: var(--border) !important; }

/* progress bar */
.pbar-wrap { height: 6px; background: var(--bg3); border-radius: 3px; overflow: hidden; margin-top: 4px; }
.pbar-fill { height: 100%; border-radius: 3px; }

.scrollable { max-height: 520px; overflow-y: auto; padding-right: 4px; }
</style>
""", unsafe_allow_html=True)

# ── 색상 헬퍼 ──────────────────────────────────────────────────────────────────
def chg_cls(v): return "up" if v >= 0 else "dn"
def chg_arrow(v): return "▲" if v >= 0 else "▼"
def badge_cls(t):
    m = {"한국주식":"b-kr","미국주식":"b-us","ETF":"b-etf","암호화폐":"b-crypto"}
    return m.get(t, "b-other")

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="padding:12px 0 8px">
        <div style="font-size:22px;font-weight:900;letter-spacing:-0.5px;
            background:linear-gradient(90deg,#00e5b4,#4d9fff);
            -webkit-background-clip:text;-webkit-text-fill-color:transparent;">
            📊 Portfolio AI
        </div>
        <div style="font-size:11px;color:#6b7f99;margin-top:2px;">스마트 자산 관리 시스템</div>
    </div>
    """, unsafe_allow_html=True)
    st.markdown("---")

    page = st.radio("", [
        "🏠 대시보드", "💼 포트폴리오 관리", "₿ 암호화폐",
        "📰 뉴스 & 리서치", "📎 스크랩북", "🤖 AI 분석",
    ], label_visibility="collapsed")

    st.markdown("---")
    with st.expander("⚙️ API 설정", expanded=False):
        g_key = st.text_input("Gemini API Key", value=os.getenv("GEMINI_API_KEY",""), type="password", key="gkey")
        n_key = st.text_input("Notion API Key", value=os.getenv("NOTION_API_KEY",""), type="password", key="nkey")
        n_db  = st.text_input("Notion DB ID",   value=os.getenv("NOTION_DATABASE_ID",""), key="ndb")
        if g_key: os.environ["GEMINI_API_KEY"] = g_key
        if n_key: os.environ["NOTION_API_KEY"] = n_key
        if n_db:  os.environ["NOTION_DATABASE_ID"] = n_db

    gemini_ok = bool(os.getenv("GEMINI_API_KEY","")) and not os.getenv("GEMINI_API_KEY","").startswith("your_")
    notion_ok  = bool(os.getenv("NOTION_API_KEY","")) and not os.getenv("NOTION_API_KEY","").startswith("your_")
    st.markdown(f"{'🟢' if gemini_ok else '🔴'} Gemini {'연결됨' if gemini_ok else '미설정'}")
    st.markdown(f"{'🟢' if notion_ok  else '🔴'} Notion  {'연결됨' if notion_ok  else '미설정'}")

    usd_krw = get_usd_krw_rate()
    jpy_krw = get_jpy_krw_rate()
    st.markdown(f"""<div style='font-size:11px;color:#6b7f99;margin-top:8px;line-height:1.9;'>
        💱 USD/KRW &nbsp;<b style='color:#dde5f0;font-family:Space Mono,monospace;'>{usd_krw:,.0f}</b><br>
        💴 JPY/KRW &nbsp;<b style='color:#dde5f0;font-family:Space Mono,monospace;'>{jpy_krw:.2f}</b> <span style='font-size:10px;'>(100엔)</span>
    </div>""", unsafe_allow_html=True)

# ── 공통 데이터 ────────────────────────────────────────────────────────────────
db = load_portfolio()
assets = db.get("assets", [])


# ════════════════════════════════════════════════════════════════════════════════
# 1) 대시보드
# ════════════════════════════════════════════════════════════════════════════════
if page == "🏠 대시보드":
    st.markdown("""<div class="header-bar">
        <div>
            <div class="logo-main">📊 Portfolio AI</div>
            <div class="logo-sub">실시간 자산 관리 & AI 투자 전략 플랫폼</div>
        </div>
    </div>""", unsafe_allow_html=True)

    # 시장 지수
    st.markdown('<div class="sec">📡 실시간 시장 지표</div>', unsafe_allow_html=True)
    with st.spinner("시장 데이터 로딩 중…"):
        indices = get_market_indices()

    if indices:
        cols_per_row = 6
        for i in range(0, len(indices), cols_per_row):
            cols = st.columns(cols_per_row)
            for j, idx in enumerate(indices[i:i+cols_per_row]):
                chg = idx["change_pct"]
                cls = chg_cls(chg); arrow = chg_arrow(chg)
                with cols[j]:
                    st.markdown(f"""<div class="idx-pill">
                        <div class="idx-name">{idx['name']}</div>
                        <div class="idx-val {cls}">{idx['value']:,.2f}</div>
                        <div class="idx-chg {cls}">{arrow} {abs(chg):.2f}%</div>
                    </div>""", unsafe_allow_html=True)

    st.markdown("---")

    # 포트폴리오 요약
    if not assets:
        st.info("💡 '포트폴리오 관리' 메뉴에서 자산을 추가해보세요.")
    else:
        st.markdown('<div class="sec">💼 포트폴리오 현황</div>', unsafe_allow_html=True)
        with st.spinner("포트폴리오 데이터 로딩…"):
            df = get_portfolio_summary(assets)

        if not df.empty:
            total_val_krw = df["현재가치(KRW)"].sum()
            total_cost_krw = (df["평균단가"] * df["수량"] * (usd_krw if True else 1)).sum()
            # 정확한 cost 계산
            cost_rows = []
            for a in assets:
                info = get_stock_info(normalize_crypto_ticker(a["ticker"]))
                if info.get("valid"):
                    c = a.get("quantity",0) * a.get("avg_price",0)
                    rate = usd_krw if info.get("currency","USD") == "USD" else 1.0
                    cost_rows.append(c * rate)
            total_cost_krw = sum(cost_rows) if cost_rows else total_val_krw
            total_pl_krw = df["손익(KRW)"].sum()
            total_pl_pct = (total_pl_krw / total_cost_krw * 100) if total_cost_krw else 0
            day_chg_pct = df["등락률(%)"].mean()

            c1, c2, c3, c4 = st.columns(4)
            cards = [
                ("총 평가가치", f"₩{total_val_krw:,.0f}", "", ""),
                ("총 투자비용", f"₩{total_cost_krw:,.0f}", "", ""),
                ("총 손익", f"₩{total_pl_krw:+,.0f}", f"{total_pl_pct:+.2f}%", chg_cls(total_pl_krw)),
                ("오늘 평균 등락", f"{day_chg_pct:+.2f}%", f"{len(assets)}개 종목", chg_cls(day_chg_pct)),
            ]
            for col, (label, val, sub, cls) in zip([c1,c2,c3,c4], cards):
                with col:
                    st.markdown(f"""<div class="stat-card">
                        <div class="stat-label">{label}</div>
                        <div class="stat-value {cls}">{val}</div>
                        {f'<div class="stat-sub {cls}">{sub}</div>' if sub else ''}
                    </div>""", unsafe_allow_html=True)

            st.markdown("<br>", unsafe_allow_html=True)
            col_l, col_r = st.columns(2)
            with col_l:
                fig_pie = px.pie(df, values="현재가치(KRW)", names="티커",
                    title="자산 비중 (KRW 기준)",
                    color_discrete_sequence=["#00e5b4","#4d9fff","#f59e0b","#f472b6","#a78bfa","#34d399","#60a5fa"])
                fig_pie.update_traces(textposition="inside", textinfo="percent+label")
                fig_pie.update_layout(paper_bgcolor="#0c1220", plot_bgcolor="#0c1220",
                    font_color="#dde5f0", title_font_color="#dde5f0",
                    legend=dict(bgcolor="rgba(0,0,0,0)"), margin=dict(l=10,r=10,t=40,b=10))
                st.plotly_chart(fig_pie, use_container_width=True)

            with col_r:
                colors = ["#00e5b4" if v>=0 else "#ff4466" for v in df["손익률(%)"]]
                fig_bar = go.Figure(go.Bar(
                    x=df["티커"], y=df["손익률(%)"],
                    marker_color=colors,
                    text=[f"{v:+.1f}%" for v in df["손익률(%)"]],
                    textposition="outside", textfont=dict(size=11)
                ))
                fig_bar.update_layout(title="종목별 수익률 (%)",
                    paper_bgcolor="#0c1220", plot_bgcolor="#0c1220",
                    font_color="#dde5f0", title_font_color="#dde5f0",
                    xaxis=dict(gridcolor="#1a2d47"), yaxis=dict(gridcolor="#1a2d47",zeroline=True,zerolinecolor="#2a4060"),
                    margin=dict(l=10,r=10,t=40,b=10))
                st.plotly_chart(fig_bar, use_container_width=True)

            # 유형별 파이
            type_df = df.groupby("유형")["현재가치(KRW)"].sum().reset_index()
            fig_type = px.pie(type_df, values="현재가치(KRW)", names="유형",
                title="자산 유형별 비중",
                color_discrete_map={"한국주식":"#4ade80","미국주식":"#60a5fa","ETF":"#fbbf24","암호화폐":"#f472b6","기타":"#a78bfa"})
            fig_type.update_layout(paper_bgcolor="#0c1220", plot_bgcolor="#0c1220",
                font_color="#dde5f0", title_font_color="#dde5f0",
                legend=dict(bgcolor="rgba(0,0,0,0)"), margin=dict(l=10,r=10,t=40,b=10))
            st.plotly_chart(fig_type, use_container_width=True)

    # 시장 뉴스
    st.markdown('<div class="sec">📰 시장 뉴스</div>', unsafe_allow_html=True)
    with st.spinner("뉴스 로딩…"):
        market_news = get_general_market_news(10)
    if not market_news:
        st.info("최신 뉴스가 없습니다.")
    for n in market_news:
        c_n, c_s = st.columns([6, 1])
        with c_n:
            st.markdown(f"""<div class="nc">
                <div class="nc-title"><a href="{n['link']}" target="_blank">🔗 {n['title']}</a></div>
                <div class="nc-meta">📰 {n.get('source','—')} &nbsp;·&nbsp; 🕐 {n.get('published','')[:16]}</div>
            </div>""", unsafe_allow_html=True)
        with c_s:
            sk = f"db_sc_{hash(n['title']) % 99999}"
            if st.button("📎 스크랩", key=sk):
                ok = add_scrap(n["title"], n["link"], n.get("summary",""), "시장전반", "시장뉴스", n.get("source",""))
                if ok:
                    saved, smsg = save_to_notion(n["title"], n["link"], n.get("summary",""), "시장전반", "시장뉴스", n.get("source",""))
                    st.success(f"저장! {smsg if saved else '(Notion 미설정)'}")
                else:
                    st.info("이미 스크랩됨")


# ════════════════════════════════════════════════════════════════════════════════
# 2) 포트폴리오 관리
# ════════════════════════════════════════════════════════════════════════════════
elif page == "💼 포트폴리오 관리":
    st.markdown('<div class="sec">💼 자산 포트폴리오</div>', unsafe_allow_html=True)

    tab_view, tab_add, tab_edit = st.tabs(["📋 보유 현황", "➕ 자산 추가", "✏️ 수정 / 삭제"])

    with tab_add:
        st.markdown("#### 새 자산 추가")
        st.markdown("""
        <div style="font-size:12px;color:#6b7f99;background:#0c1220;border:1px solid #1a2d47;border-radius:8px;padding:10px 14px;margin-bottom:16px;">
        💡 <b>티커 예시</b>: 한국 주식 <code>005930.KS</code>(삼성전자) &nbsp;|&nbsp;
        미국 주식 <code>AAPL</code>, <code>TSLA</code> &nbsp;|&nbsp;
        ETF <code>QQQ</code>, <code>069500.KS</code>(KODEX200) &nbsp;|&nbsp;
        암호화폐 <code>BTC</code>, <code>ETH</code>, <code>BTC-USD</code>
        </div>""", unsafe_allow_html=True)

        c1, c2 = st.columns(2)
        with c1:
            new_ticker = st.text_input("티커 심볼 *", placeholder="예: AAPL / 005930.KS / BTC")
            auto_type = detect_asset_type(new_ticker) if new_ticker else "미국주식"
            new_type = st.selectbox("자산 유형", ASSET_TYPES, index=ASSET_TYPES.index(auto_type) if auto_type in ASSET_TYPES else 0)
            new_note = st.text_input("메모 (선택)")
        with c2:
            new_qty = st.number_input("보유 수량 *", min_value=0.000001, value=1.0, format="%.6f")
            new_avg = st.number_input("평균 매입단가 *", min_value=0.000001, value=100.0, format="%.4f")
            new_name = st.text_input("종목명 (비우면 자동 조회)")

        if st.button("✅ 추가하기", use_container_width=True):
            if not new_ticker.strip():
                st.error("티커를 입력해주세요.")
            else:
                with st.spinner("종목 확인 중…"):
                    info = get_stock_info(new_ticker.strip())
                final_name = new_name.strip() if new_name.strip() else info.get("name", new_ticker)
                ok, msg = add_asset(new_ticker.strip(), final_name, new_qty, new_avg, new_type, new_note)
                if ok:
                    st.success(msg)
                    if info.get("valid"):
                        st.info(f"📌 현재가: {info['current_price']:,.4f} {info['currency']} | 섹터: {info.get('sector','—')}")
                    st.rerun()
                else:
                    st.warning(msg)

    with tab_view:
        if not assets:
            st.info("보유 자산이 없습니다. '자산 추가' 탭에서 추가해주세요.")
        else:
            with st.spinner("데이터 로딩…"):
                df = get_portfolio_summary(assets)

            if not df.empty:
                # 스타일 함수
                def highlight(val):
                    if isinstance(val, (int,float)):
                        if val > 0: return "color: #00e5b4; font-weight:600"
                        elif val < 0: return "color: #ff4466; font-weight:600"
                    return ""

                styled = df.style.applymap(highlight, subset=["손익","손익(KRW)","손익률(%)","등락률(%)"])
                st.dataframe(styled, use_container_width=True, height=400)

                total_val_krw = df["현재가치(KRW)"].sum()
                total_pl_krw  = df["손익(KRW)"].sum()
                st.markdown(f"""
                <div style="display:flex;gap:16px;margin-top:10px;">
                    <div class="stat-card" style="flex:1">
                        <div class="stat-label">총 평가가치 (KRW)</div>
                        <div class="stat-value">₩{total_val_krw:,.0f}</div>
                    </div>
                    <div class="stat-card" style="flex:1">
                        <div class="stat-label">총 손익 (KRW)</div>
                        <div class="stat-value {chg_cls(total_pl_krw)}">₩{total_pl_krw:+,.0f}</div>
                    </div>
                </div>""", unsafe_allow_html=True)

                # 차트
                st.markdown("<br>", unsafe_allow_html=True)
                sel_ticker = st.selectbox("📈 차트 조회 종목", [a["ticker"] for a in assets],
                    format_func=lambda t: next((f"{a['ticker']} — {a['name']}" for a in assets if a['ticker'] == t), t))
                period = st.select_slider("기간", ["1mo","3mo","6mo","1y","2y","5y"], value="3mo")

                with st.spinner("차트 로딩…"):
                    hist = get_price_history(sel_ticker, period)

                if not hist.empty:
                    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.05, row_heights=[0.75,0.25])
                    fig.add_trace(go.Candlestick(
                        x=hist.index, open=hist["Open"], high=hist["High"],
                        low=hist["Low"], close=hist["Close"],
                        increasing_line_color="#00e5b4", decreasing_line_color="#ff4466", name="주가"
                    ), row=1, col=1)
                    # 이동평균선
                    for w, color in [(20,"#f59e0b"),(60,"#f472b6")]:
                        if len(hist) >= w:
                            ma = hist["Close"].rolling(w).mean()
                            fig.add_trace(go.Scatter(x=hist.index, y=ma, mode="lines",
                                line=dict(color=color, width=1.5), name=f"MA{w}"), row=1, col=1)
                    fig.add_trace(go.Bar(x=hist.index, y=hist["Volume"],
                        marker_color="#4d9fff", opacity=0.5, name="거래량"), row=2, col=1)
                    fig.update_layout(
                        height=480, paper_bgcolor="#0c1220", plot_bgcolor="#0c1220",
                        font_color="#dde5f0", xaxis_rangeslider_visible=False,
                        xaxis=dict(gridcolor="#1a2d47"), xaxis2=dict(gridcolor="#1a2d47"),
                        yaxis=dict(gridcolor="#1a2d47"), yaxis2=dict(gridcolor="#1a2d47"),
                        legend=dict(bgcolor="rgba(0,0,0,0)"),
                        margin=dict(l=10,r=10,t=20,b=10)
                    )
                    st.plotly_chart(fig, use_container_width=True)

    with tab_edit:
        if not assets:
            st.info("보유 자산이 없습니다.")
        else:
            st.markdown("#### 수량 / 단가 수정")
            edit_ticker = st.selectbox("수정할 종목", [a["ticker"] for a in assets], key="edit_sel",
                format_func=lambda t: next((f"{a['ticker']} — {a['name']}" for a in assets if a['ticker'] == t), t))
            cur = next((a for a in assets if a["ticker"] == edit_ticker), {})
            c1, c2 = st.columns(2)
            with c1: new_qty2 = st.number_input("수량", value=float(cur.get("quantity",1)), format="%.6f", key="eq")
            with c2: new_avg2 = st.number_input("평균단가", value=float(cur.get("avg_price",0)), format="%.4f", key="ea")
            if st.button("💾 수정 저장", use_container_width=True):
                update_asset(edit_ticker, new_qty2, new_avg2)
                st.success("저장됐습니다."); st.rerun()

            st.markdown("---")
            st.markdown("#### 자산 삭제")
            del_ticker = st.selectbox("삭제할 종목", [a["ticker"] for a in assets], key="del_sel",
                format_func=lambda t: next((f"{a['ticker']} — {a['name']}" for a in assets if a['ticker'] == t), t))
            if st.button(f"🗑️ {del_ticker} 삭제", type="secondary", use_container_width=True):
                remove_asset(del_ticker)
                st.success(f"{del_ticker} 삭제됨"); st.rerun()


# ════════════════════════════════════════════════════════════════════════════════
# 3) 암호화폐 전용
# ════════════════════════════════════════════════════════════════════════════════
elif page == "₿ 암호화폐":
    st.markdown('<div class="sec">₿ 암호화폐 현황</div>', unsafe_allow_html=True)

    # 주요 코인 실시간
    MAJOR_COINS = [("BTC-USD","비트코인"),("ETH-USD","이더리움"),("SOL-USD","솔라나"),
                   ("XRP-USD","리플"),("ADA-USD","에이다"),("DOGE-USD","도지")]
    coin_cols = st.columns(3)
    for i, (ticker, name) in enumerate(MAJOR_COINS):
        info = get_stock_info(ticker)
        with coin_cols[i % 3]:
            if info.get("valid"):
                chg = info["change_pct"]
                cls = chg_cls(chg)
                st.markdown(f"""<div class="stat-card">
                    <div class="stat-label">{name} ({ticker.replace('-USD','')})</div>
                    <div class="stat-value">${info['current_price']:,.2f}</div>
                    <div class="stat-sub {cls}">{chg_arrow(chg)} {abs(chg):.2f}%</div>
                </div>""", unsafe_allow_html=True)

    st.markdown("---")

    # 보유 코인 목록
    crypto_assets = [a for a in assets if a.get("asset_type") == "암호화폐"]
    if crypto_assets:
        st.markdown('<div class="sec">📦 보유 코인</div>', unsafe_allow_html=True)
        with st.spinner("코인 데이터 로딩…"):
            c_df = get_portfolio_summary(crypto_assets)
        if not c_df.empty:
            def color_num(v):
                if isinstance(v,(int,float)):
                    if v > 0: return "color:#00e5b4;font-weight:600"
                    elif v < 0: return "color:#ff4466;font-weight:600"
                return ""
            st.dataframe(c_df.style.applymap(color_num, subset=["손익","손익(KRW)","손익률(%)"]),
                use_container_width=True)
    else:
        st.info("보유 암호화폐가 없습니다. 포트폴리오 관리에서 유형을 '암호화폐'로 추가하세요.")

    st.markdown("---")
    st.markdown('<div class="sec">📰 암호화폐 뉴스</div>', unsafe_allow_html=True)
    with st.spinner("코인 뉴스 로딩…"):
        crypto_news = get_crypto_news(10)
    for n in crypto_news:
        c_n, c_s = st.columns([5,1])
        with c_n:
            st.markdown(f"""<div class="nc">
                <div class="nc-title"><a href="{n['link']}" target="_blank">🔗 {n['title']}</a></div>
                <div class="nc-meta">📰 {n.get('source','—')} &nbsp;·&nbsp; {n.get('published','')[:16]}</div>
            </div>""", unsafe_allow_html=True)
        with c_s:
            sk = f"cs_{n['title'][:12]}"
            if st.button("📎", key=sk):
                ok = add_scrap(n["title"], n["link"], n.get("summary",""), "암호화폐", "코인뉴스", n.get("source",""))
                if ok:
                    saved, msg = save_to_notion(n["title"], n["link"], n.get("summary",""), "암호화폐", "코인뉴스", n.get("source",""))
                    st.success(f"저장! {msg if saved else ''}")
                else:
                    st.info("이미 스크랩됨")


# ════════════════════════════════════════════════════════════════════════════════
# 4) 뉴스 & 리서치
# ════════════════════════════════════════════════════════════════════════════════
elif page == "📰 뉴스 & 리서치":
    st.markdown('<div class="sec">📰 뉴스 & 리서치</div>', unsafe_allow_html=True)

    tab1, tab2, tab3 = st.tabs(["📌 보유 자산 뉴스", "🌍 시장 전반", "🔬 리서치 & 분석"])

    with tab1:
        st.markdown("<div style='font-size:11px;color:#6b7f99;margin-bottom:10px;'>📰 최신 뉴스 & 리서치 자료</div>", unsafe_allow_html=True)
        if not assets:
            st.info("보유 자산이 없습니다.")
        else:
            sel = st.selectbox("자산 선택", [a["ticker"] for a in assets],
                format_func=lambda t: f"{ASSET_TYPE_ICONS.get(next((a['asset_type'] for a in assets if a['ticker']==t),'기타'),'💼')} {t} — {next((a['name'] for a in assets if a['ticker']==t), t)}")
            a_info = next((a for a in assets if a["ticker"] == sel), {})
            with st.spinner(f"{sel} 뉴스 검색 중…"):
                news_list = get_news_for_asset(sel, a_info.get("name",""), a_info.get("asset_type",""))
            if not news_list:
                st.warning("검색된 뉴스가 없습니다.")
            else:
                for n in news_list:
                    c_n, c_s = st.columns([5,1])
                    with c_n:
                        st.markdown(f"""<div class="nc">
                            <div class="nc-title"><a href="{n['link']}" target="_blank">🔗 {n['title']}</a></div>
                            <div class="nc-meta">📰 {n.get('source','—')} &nbsp;·&nbsp; 🕐 {n.get('published','')[:16]}</div>
                            <div style="font-size:11px;color:#6b7f99;margin-top:5px;">{n.get('summary','')}</div>
                        </div>""", unsafe_allow_html=True)
                    with c_s:
                        sk = f"ns_{sel}_{hash(n['title']) % 99999}"
                        if st.button("📎 스크랩", key=sk):
                            ok = add_scrap(n["title"], n["link"], n.get("summary",""), sel, a_info.get("asset_type","주식"), n.get("source",""))
                            if ok:
                                saved, msg = save_to_notion(n["title"], n["link"], n.get("summary",""), sel, a_info.get("asset_type","주식"), n.get("source",""))
                                st.success(f"저장! {msg if saved else '(Notion 미설정)'}")
                            else:
                                st.info("이미 스크랩됨")

    with tab2:
        st.markdown("<div style='font-size:11px;color:#6b7f99;margin-bottom:10px;'>📰 최신 시장 뉴스 & 리서치 자료</div>", unsafe_allow_html=True)
        with st.spinner("뉴스 로딩…"):
            m_news = get_general_market_news(14)
        if not m_news:
            st.info("최신 뉴스가 없습니다.")
        for n in m_news:
            c_n, c_s = st.columns([5,1])
            with c_n:
                st.markdown(f"""<div class="nc">
                    <div class="nc-title"><a href="{n['link']}" target="_blank">🔗 {n['title']}</a></div>
                    <div class="nc-meta">📰 {n.get('source','—')} &nbsp;·&nbsp; 🕐 {n.get('published','')[:16]}</div>
                </div>""", unsafe_allow_html=True)
            with c_s:
                mk = f"mn_{hash(n['title']) % 99999}"
                if st.button("📎", key=mk):
                    ok = add_scrap(n["title"], n["link"], n.get("summary",""), "시장전반", "시장뉴스", n.get("source",""))
                    if ok:
                        saved, smsg = save_to_notion(n["title"], n["link"], n.get("summary",""), "시장전반", "시장뉴스", n.get("source",""))
                        st.success(f"저장! {smsg if saved else ''}")
                    else:
                        st.info("이미 스크랩됨")

    with tab3:
        st.markdown("<div style='font-size:11px;color:#6b7f99;margin-bottom:10px;'>📊 최신 리서치 & 분석 자료</div>", unsafe_allow_html=True)
        r_query_options = ["전체 시장"] + ([a["ticker"] + " " + a["name"] for a in assets] if assets else [])
        r_sel = st.selectbox("리서치 주제 선택", r_query_options, key="research_sel")
        r_query = r_sel if r_sel != "전체 시장" else "주식시장 경제 전망 리포트"
        r_ticker = r_sel.split(" ")[0] if r_sel != "전체 시장" else "시장전반"

        with st.spinner("리서치 자료 검색 중…"):
            r_news = get_research_news(r_query, max_items=10)

        if not r_news:
            st.info("리서치 자료가 없습니다.")
        else:
            for n in r_news:
                c_n, c_s = st.columns([5,1])
                with c_n:
                    st.markdown(f"""<div class="nc">
                        <div class="nc-title"><a href="{n['link']}" target="_blank">🔗 {n['title']}</a></div>
                        <div class="nc-meta">📰 {n.get('source','—')} &nbsp;·&nbsp; 🕐 {n.get('published','')[:16]}</div>
                        <div style="font-size:11px;color:#6b7f99;margin-top:5px;">{n.get('summary','')}</div>
                    </div>""", unsafe_allow_html=True)
                with c_s:
                    rk = f"rn_{hash(n['title']) % 99999}"
                    if st.button("📎 스크랩", key=rk):
                        ok = add_scrap(n["title"], n["link"], n.get("summary",""), r_ticker, "리서치", n.get("source",""))
                        if ok:
                            saved, msg = save_to_notion(n["title"], n["link"], n.get("summary",""), r_ticker, "리서치", n.get("source",""))
                            st.success(f"저장! {msg if saved else '(Notion 미설정)'}")
                        else:
                            st.info("이미 스크랩됨")


# ════════════════════════════════════════════════════════════════════════════════
# 5) 스크랩북
# ════════════════════════════════════════════════════════════════════════════════
elif page == "📎 스크랩북":
    st.markdown('<div class="sec">📎 스크랩북</div>', unsafe_allow_html=True)
    scraps = get_scraps()

    if not scraps:
        st.info("스크랩된 항목이 없습니다. 뉴스 탭에서 스크랩해보세요!")
    else:
        # 필터
        c1, c2, c3 = st.columns(3)
        with c1:
            all_tickers = sorted(set(s.get("ticker","") for s in scraps))
            f_ticker = st.selectbox("자산 필터", ["전체"] + all_tickers)
        with c2:
            all_cats = sorted(set(s.get("category","") for s in scraps))
            f_cat = st.selectbox("카테고리", ["전체"] + all_cats)
        with c3:
            sort_opt = st.selectbox("정렬", ["최신순", "오래된순", "자산순"])

        filtered = [s for s in scraps
            if (f_ticker == "전체" or s.get("ticker") == f_ticker)
            and (f_cat == "전체" or s.get("category") == f_cat)]

        if sort_opt == "최신순":   filtered = sorted(filtered, key=lambda x: x.get("scraped_at",""), reverse=True)
        elif sort_opt == "오래된순": filtered = sorted(filtered, key=lambda x: x.get("scraped_at",""))
        else:                      filtered = sorted(filtered, key=lambda x: x.get("ticker",""))

        st.markdown(f"<div style='font-size:12px;color:#6b7f99;margin-bottom:12px;'>총 <b>{len(filtered)}</b>개</div>", unsafe_allow_html=True)

        for s in filtered:
            c_s, c_d = st.columns([7,1])
            with c_s:
                date = s.get("scraped_at","")[:10]
                link = s.get("link","#")
                st.markdown(f"""<div class="nc">
                    <div class="nc-title"><a href="{link}" target="_blank">🔗 {s['title']}</a></div>
                    <div style="margin:5px 0;">
                        <span class="tag">📌 {s.get('ticker','—')}</span>
                        <span class="tag">🗂️ {s.get('category','—')}</span>
                        <span class="tag">📅 {date}</span>
                        <span class="tag">📰 {s.get('source','—')}</span>
                    </div>
                    <div style="font-size:11px;color:#6b7f99;">{s.get('summary','')[:150]}</div>
                </div>""", unsafe_allow_html=True)
            with c_d:
                if st.button("🗑️", key=f"ds_{s.get('id')}"):
                    delete_scrap(s.get("id")); st.rerun()


# ════════════════════════════════════════════════════════════════════════════════
# 6) AI 분석
# ════════════════════════════════════════════════════════════════════════════════
elif page == "🤖 AI 분석":
    st.markdown('<div class="sec">🤖 AI 포트폴리오 분석</div>', unsafe_allow_html=True)

    if not gemini_ok:
        st.warning("⚠️ 사이드바 → API 설정에서 Gemini API 키를 입력해주세요.")

    # 현황 카드
    scraps_all = get_scraps()
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown(f"""<div class="stat-card">
            <div class="stat-label">보유 자산</div>
            <div class="stat-value">{len(assets)}종목</div>
        </div>""", unsafe_allow_html=True)
    with c2:
        st.markdown(f"""<div class="stat-card">
            <div class="stat-label">스크랩 정보</div>
            <div class="stat-value">{len(scraps_all)}건</div>
        </div>""", unsafe_allow_html=True)
    with c3:
        ai_cnt = len([s for s in scraps_all if s.get("category")=="AI분석"])
        st.markdown(f"""<div class="stat-card">
            <div class="stat-label">AI 분석 이력</div>
            <div class="stat-value">{ai_cnt}회</div>
        </div>""", unsafe_allow_html=True)

    st.markdown("---")

    # 분석 옵션
    col_opt1, col_opt2 = st.columns(2)
    with col_opt1:
        focus = st.multiselect("분석 중점 항목", ["포트폴리오 진단","헷지 전략","섹터 분석","암호화폐 분석","리스크 관리","단기 매매 포인트"],
            default=["포트폴리오 진단","헷지 전략","리스크 관리"])
    with col_opt2:
        risk_pref = st.select_slider("리스크 선호도", ["매우 보수적","보수적","중립","공격적","매우 공격적"], value="보수적")

    prompt_extra = st.text_area("추가 질문 / 특이사항",
        placeholder="예: 미국 금리 인하 시 포트폴리오 대응 방법은?\n예: 현재 달러 현금 비중을 높이고 싶습니다. 어떻게 생각하시나요?",
        height=90)

    focus_str = ", ".join(focus) if focus else "전반적 분석"
    full_prompt = f"[분석 중점: {focus_str}] [리스크 선호도: {risk_pref}]\n{prompt_extra}" if prompt_extra else f"[분석 중점: {focus_str}] [리스크 선호도: {risk_pref}]"

    if st.button("🤖 AI 분석 시작", use_container_width=True, disabled=not gemini_ok):
        with st.spinner("🧠 Gemini가 포트폴리오를 분석 중입니다… (30초~1분)"):
            with st.spinner("시장 데이터 수집…"):
                df = get_portfolio_summary(assets) if assets else pd.DataFrame()
                indices = get_market_indices()
            result = get_gemini_analysis(df, scraps_all, indices, full_prompt)

        st.markdown('<div class="sec">📊 AI 분석 결과</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="ai-box">{result}</div>', unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        c_save1, c_save2 = st.columns([1,3])
        with c_save1:
            if st.button("📎 결과 스크랩"):
                add_scrap(
                    f"AI 분석 {datetime.now().strftime('%Y-%m-%d %H:%M')}",
                    "", result[:600], "전체포트폴리오", "AI분석", "Gemini AI"
                )
                saved, smsg = save_to_notion(
                    f"AI 포트폴리오 분석 {datetime.now().strftime('%Y-%m-%d')}",
                    "", result[:1800], "전체포트폴리오", "AI분석", "Gemini AI"
                )
                st.success(f"저장 완료! {smsg if saved else '(Notion 미설정)'}")

    # 이전 AI 분석 이력
    ai_scraps = [s for s in scraps_all if s.get("category") == "AI분석"]
    if ai_scraps:
        st.markdown("---")
        st.markdown('<div class="sec">📜 이전 AI 분석 이력</div>', unsafe_allow_html=True)
        for s in sorted(ai_scraps, key=lambda x: x.get("scraped_at",""), reverse=True)[:5]:
            with st.expander(f"📅 {s.get('scraped_at','')[:16]}"):
                st.markdown(s.get("summary",""))
